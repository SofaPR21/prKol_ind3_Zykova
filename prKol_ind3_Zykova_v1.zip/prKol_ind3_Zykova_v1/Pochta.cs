﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind3_Zykova_v1
{
    class Pochta
    {
        private string nameOrganiz; //название организации

        private string street; //улица

        private int houseNumber; //номер дома

        private int apartmentNumber; //номер квартиры

        private string locality; //название населеного пункта

        private string republic; //название района/края/республики

        private string country; //название страны

        private string pochtaIndex; //почтовый индекс

        public Pochta() { }
        public Pochta(string nameOrganiz, string street, int houseNumber, int apartmentNumber, string locality, string republic, string country, string pochtaIndex)
        {
            this.nameOrganiz = nameOrganiz;
            this.street = street;
            this.houseNumber = houseNumber;
            this.apartmentNumber = apartmentNumber;
            this.locality = locality;
            this.republic = republic;
            this.country = country;
            this.pochtaIndex = pochtaIndex;
        }

        public string NameOrganiz
        {
            get { return nameOrganiz; }
            set { nameOrganiz = value; }
        }

        public string Street
        {
            get { return street; }
            set { street = value; }
        }

        public int HouseNumber
        {
            get { return houseNumber; }
            set { houseNumber = value; }
        }

        public int ApartmentNumber
        {
            get { return apartmentNumber; }
            set { apartmentNumber = value; }
        }

        public string Locality
        {
            get { return locality; }
            set { locality = value; }
        }

        public string Republic
        {
            get { return republic; }
            set { republic = value; }
        }

        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public string PochtaIndex
        {
            get { return pochtaIndex; }
            set { pochtaIndex = value; }
        }

        public void UpdateStreet(string street)
        {
            this.street = street;
        }

        public void UpdateHouseNumber(int houseNumber)
        {
            this.houseNumber = houseNumber;
        }

        public void UpdateApartmentNumber(int apartmentNumber)
        {
            this.apartmentNumber = apartmentNumber;
        }

        public void UpdateLocality(string locality)
        {
            this.locality = locality;
        }

        public void UpdateRepublic(string republic)
        {
            this.republic = republic;
        }

        public void UpdateCountry(string country)
        {
            this.country = country;
        }

        public void UpdatePochtaIndex(string pochtaIndex)
        {
            this.pochtaIndex = pochtaIndex;
        }

        //создание почты
        public static Pochta CreatePochta(string nameOrganiz, string street, int houseNumber, int apartmentNumber, string locality, string republic, string country, string pochtaIndex)
        {
            return new Pochta(nameOrganiz, street, houseNumber, apartmentNumber, locality, republic, country, pochtaIndex);
        }

        //вывод в листбокс
        public override string ToString()
        {
            return $"{NameOrganiz}, \nул. {Street}, \nд. {HouseNumber}, \nкв. {ApartmentNumber}, \n{Locality}, \n{Republic}, \n{Country}, \n{PochtaIndex}";
        }

        public static void DestroyPochta(Pochta pochta)
        {
           
        }

    }
}
