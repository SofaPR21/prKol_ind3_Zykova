﻿
namespace prKol_ind3_Zykova_v1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
            toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            textBox1 = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            textBox2 = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            textBox5 = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            textBox6 = new System.Windows.Forms.TextBox();
            label7 = new System.Windows.Forms.Label();
            textBox7 = new System.Windows.Forms.TextBox();
            label8 = new System.Windows.Forms.Label();
            textBox8 = new System.Windows.Forms.TextBox();
            numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            listBox1 = new System.Windows.Forms.ListBox();
            contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem2 });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new System.Drawing.Size(119, 48);
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new System.Drawing.Size(118, 22);
            toolStripMenuItem1.Text = "Удалить";
            toolStripMenuItem1.Click += toolStripMenuItem1_Click;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            toolStripMenuItem2.Text = "Создать";
            toolStripMenuItem2.Click += toolStripMenuItem2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new System.Drawing.Point(50, 58);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(142, 23);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(50, 40);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(142, 15);
            label1.TabIndex = 2;
            label1.Text = "Полное имя получателя";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(50, 100);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(98, 15);
            label2.TabIndex = 4;
            label2.Text = "Название улицы";
            // 
            // textBox2
            // 
            textBox2.Location = new System.Drawing.Point(50, 118);
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(142, 23);
            textBox2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(50, 163);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(76, 15);
            label3.TabIndex = 6;
            label3.Text = "Номер дома";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(48, 223);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(101, 15);
            label4.TabIndex = 8;
            label4.Text = "Номер квартиры";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(219, 40);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(173, 15);
            label5.TabIndex = 10;
            label5.Text = "Название населенного пункта";
            // 
            // textBox5
            // 
            textBox5.Location = new System.Drawing.Point(219, 58);
            textBox5.Name = "textBox5";
            textBox5.Size = new System.Drawing.Size(144, 23);
            textBox5.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(219, 100);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(256, 15);
            label6.TabIndex = 12;
            label6.Text = "Название района, области, края, республики";
            // 
            // textBox6
            // 
            textBox6.Location = new System.Drawing.Point(219, 118);
            textBox6.Name = "textBox6";
            textBox6.Size = new System.Drawing.Size(144, 23);
            textBox6.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(219, 163);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(102, 15);
            label7.TabIndex = 14;
            label7.Text = "Название страны";
            // 
            // textBox7
            // 
            textBox7.Location = new System.Drawing.Point(219, 181);
            textBox7.Name = "textBox7";
            textBox7.Size = new System.Drawing.Size(144, 23);
            textBox7.TabIndex = 13;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(219, 223);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(105, 15);
            label8.TabIndex = 16;
            label8.Text = "Почтовый индекс";
            // 
            // textBox8
            // 
            textBox8.Location = new System.Drawing.Point(219, 241);
            textBox8.Name = "textBox8";
            textBox8.Size = new System.Drawing.Size(144, 23);
            textBox8.TabIndex = 15;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new System.Drawing.Point(50, 182);
            numericUpDown1.Maximum = new decimal(new int[] { 756, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new System.Drawing.Size(120, 23);
            numericUpDown1.TabIndex = 20;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new System.Drawing.Point(50, 241);
            numericUpDown2.Maximum = new decimal(new int[] { 6313, 0, 0, 0 });
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new System.Drawing.Size(120, 23);
            numericUpDown2.TabIndex = 21;
            // 
            // listBox1
            // 
            listBox1.ContextMenuStrip = contextMenuStrip1;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new System.Drawing.Point(50, 302);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(313, 139);
            listBox1.TabIndex = 17;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(485, 480);
            Controls.Add(numericUpDown2);
            Controls.Add(numericUpDown1);
            Controls.Add(listBox1);
            Controls.Add(label8);
            Controls.Add(textBox8);
            Controls.Add(label7);
            Controls.Add(textBox7);
            Controls.Add(label6);
            Controls.Add(textBox6);
            Controls.Add(label5);
            Controls.Add(textBox5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}

