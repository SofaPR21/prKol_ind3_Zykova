﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind3_Zykova_v1
{
    public partial class Form1 : Form
    {
        private ArrayList pochtaList;
        public Form1()
        {
            InitializeComponent();
            pochtaList = new ArrayList();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*private void UpdateListBox()
        {
            listBox1.Items.Clear();
            foreach (Pochta p in pochtaList)
            {
                listBox1.Items.Add($"{p.NameOrganiz},");
                listBox1.Items.Add($"ул. { p.Street},");
                listBox1.Items.Add($"д. {p.HouseNumber},");
                listBox1.Items.Add($"кв. {p.ApartmentNumber},");
                listBox1.Items.Add($"{p.Locality},");
                listBox1.Items.Add($"{p.Republic},");
                listBox1.Items.Add($"{p.Country},");
                listBox1.Items.Add($"{p.PochtaIndex}");
            }
        }*/

        private void RemoveSelectedItem()
        {
            if (listBox1.SelectedItem != null)
            {
                Pochta selectedPochta = (Pochta)listBox1.SelectedItem;
                pochtaList.Remove(selectedPochta);
                listBox1.Items.Remove(selectedPochta);
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления", "Ошибка");
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RemoveSelectedItem();
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox5.Text) ||
                string.IsNullOrWhiteSpace(textBox6.Text) ||
                string.IsNullOrWhiteSpace(textBox7.Text) ||
                string.IsNullOrWhiteSpace(textBox8.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка валидации");
                return false;
            }

            return true;
        }

        private void CreatePochtaIndex()
        {
            if (!ValidateInput()) 
            {
                return;
            }
            Pochta newPochta = Pochta.CreatePochta(
            textBox1.Text,
            textBox2.Text,
            Convert.ToInt32(numericUpDown1.Text),
            Convert.ToInt32(numericUpDown2.Text),
            textBox5.Text,
            textBox6.Text,
            textBox7.Text,
            textBox8.Text
            );

            pochtaList.Add(newPochta);
            listBox1.Items.Add(newPochta);
        }
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            CreatePochtaIndex();
        }
    }
}
